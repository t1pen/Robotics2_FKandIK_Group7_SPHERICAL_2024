This is a Spherical Manipulator Calculator App created for the Midterm Project of Robotics 2.
Repository is posted in this Github Link: 
https://github.com/t1pen/Robotics2_FKandIK_Group7_SPHERICAL_2024/tree/main

Publisher: Stephen Alojado