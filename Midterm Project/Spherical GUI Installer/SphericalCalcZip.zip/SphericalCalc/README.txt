This is a Spherical Manipulator Calculator App created for the Midterm Project of Robotics 2.

This is the zip version of the app. Just install the fonts in the fonts folder then
you can run the .exe file. Enjoy!

Publisher: Stephen Alojado